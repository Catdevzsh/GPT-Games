## write pong with pygame client in python 3.0

import pygame
import random
import sys
import time